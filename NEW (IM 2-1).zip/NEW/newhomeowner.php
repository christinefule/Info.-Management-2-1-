<?php 

session_start();

$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "gatepass_db";
//replication to save on historical database
$dbhostH = "localhost";
$dbuserH = "root";
$dbpassH = "";
$dbnameH = "historicalgatepass_db";

    $conn= mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
    $connH= mysqli_connect($dbhostH,$dbuserH,$dbpassH,$dbnameH);

    if(isset($_POST['submit']))
    {
        $Firstname= $_POST['Firstname'];
        $Lastname= $_POST['Lastname'];
        $Email= $_POST['Email'];
        $Street_name_no= $_POST['Street_name_no'];
        $Occupation= $_POST['Occupation'];
        $Phone_number= $_POST['Phone_number'];
        $Family_member= $_POST['Family_member'];
        $No_car= $_POST['No_car'];
        

        if(!empty($No_car)  && !empty($Family_member) 
        && !empty( $Phone_number) && !empty($Occupation) && !empty( $Street_name_no) && !empty( $Email)
        && !empty($Lastname) && !empty($Firstname)){
            
            $query = "insert into clients (Firstname,Lastname,Email,Street_name_no,Occupation,Phone_number,Family_member,No_car) 
            values ('$Firstname','$Lastname',' $Email','$Street_name_no',' $Occupation','$Phone_number','$Family_member','$No_car') ";

            $run=mysqli_query($conn,$query);
            $run=mysqli_query($connH,$query);

            if($run){
               echo '<script>alert("Successfuly submitted")</script>';
               //header("Location: index.php");
            }
        }else {
            echo "error";
        }
    
    }


?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8" />
    <title>New Client Registration</title>
    <link rel="stylesheet" href="newhomeowner.css" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  </head>
  <script>
    function myFunction() {
      location.href = "index.php";
    }
  </script>
  <body>
    <style>
      body {
        background-image: url("img/Ai.jpg");
        background-color: #2e435e;
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-size: 105%;
      }
    </style>
    <div class="container">
      <div class="title" style="font-family: Garamond;"siz>New Client Registration</div>
      <div class="content">
        <form action="#" method="POST">
          <div class="user-details">
            <div class="input-box">
              <span class="details" style="font-style: italic;">First Name</span>
              <input type="text" name ="Firstname"placeholder="Type Here..." required />
            </div>
            <div class="input-box">
              <span class="details" style="font-style: italic;">Last Name</span>
              <input type="text" name ="Lastname"placeholder="Type Here..." required />
            </div>
            <div class="input-box">
              <span class="details"style="font-style: italic;">Email</span>
              <input type="text" name ="Email"placeholder="Type Here..." required />
            </div>
            <div class="input-box">
              <span class="details"style="font-style: italic;">Street Name/No.</span>
              <input
                type="text" name ="Street_name_no" placeholder="Enter your street name/no."required
              />
            </div>
            <div class="input-box">
              <span class="details"style="font-style: italic;">Occupation</span>
              <input type="text" name ="Occupation"placeholder="Type Here..." required />
            </div>
            <div class="input-box">
              <span class="details"style="font-style: italic;">Phone Number</span>
              <input type="text" name ="Phone_number"placeholder="Type Here..." required />
            </div>
            <div class="input-box">
              <span class="details"style="font-style: italic;">No. of Family member</span>
              <input type="text" name ="Family_member"placeholder="Type Here..." required />
            </div>
            <div class="input-box">
              <span class="details"style="font-style: italic;">No. of Car/s</span>
              <input type="text" name ="No_car"placeholder="Type Here..." required />
          </div>
          <button class="button" role="button" type="submit" name= "submit">Register</button>
          <button class="button" role="button" href="index.php" type="button"onclick="myFunction()" formnovalidate>Go Back</button>
        <form action="homeownerexcel.php" method="post">
            <button class="button" role="button" type="submit" name="export">Export</button>
        </form>
      </div></div>
    </div>
  </body>
</html>
