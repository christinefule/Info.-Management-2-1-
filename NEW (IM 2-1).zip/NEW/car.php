<?php 

session_start();

$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "gatepass_db";
//replication for the historical database
$dbhostH = "localhost";
$dbuserH = "root";
$dbpassH = "";
$dbnameH = "historicalgatepass_db";

    $conn= mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
    $connH= mysqli_connect($dbhostH,$dbuserH,$dbpassH,$dbnameH);
    if(isset($_POST['submit']))
    {
       
        $Owner_name= $_POST['Owner_name'];
        $Owner_no= $_POST['Owner_no'];
        $Driver_name= $_POST['Driver_name'];
        $Driver_no= $_POST['Driver_no'];
        $Plate_number= $_POST['Plate_number'];
        $Car_model= $_POST['Car_model'];
        $Car_brand= $_POST['Car_brand'];
        $Car_color= $_POST['Car_color'];

        if(!empty($Owner_name) && !empty($Owner_no) &&!empty($Driver_name) &&!empty($Driver_no) 
        &&!empty($Plate_number) && !empty($Car_model) 
        && !empty($Car_brand) && !empty($Car_color)){
            
            $query = "insert into cars (Owner_name,Owner_no,Driver_name,Driver_no,
                      Plate_number,Car_model,Car_brand,Car_color) values (
            '$Owner_name','$Owner_no','$Driver_name','$Driver_no','$Plate_number','$Car_model',
            '$Car_brand',' $Car_color') ";

            $run=mysqli_query($conn,$query);
            $run=mysqli_query($connH,$query);

            if($run){
               echo '<script>alert("Successfuly submitted")</script>';
               //header("Location: index.php");
            }
        }else {
            echo "error";
        }
    
    }


?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title> Car Registration </title>
    <link rel="stylesheet" href="car.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
   <script>
    function myFunction() {
      location.href = "index.php";
    }
  </script>
<body>
      <style>
      body {
        background-image: url("img/Ai.jpg");
        background-color: #2e435e;
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-size: 100%;
      }
    </style>
  <div class="container" >
    <div class="title" style="font-family: Garamond;">Car Registration</div>
    <div class="content">
      <form action="#"method="POST">
        <div class="user-details">
          <div class="input-box">
            <span class="details" style="font-style: italic;">Owner's Name</span>
            <input type="owner" placeholder="Type Here..." name="Owner_name"required>
          </div>
          <div class="input-box">
            <span class="details" style="font-style: italic;">Owner's Contact No.</span>
            <input type="Owner_no" placeholder="Type Here..." name= "Owner_no"required>
          </div>
          <div class="input-box">
            <span class="details"style="font-style: italic;">Driver's Name</span>
            <input type="driver" placeholder="Type Here..." name="Driver_name"required>
          </div>
          <div class="input-box">
            <span class="details"style="font-style: italic;">Driver Contact No.</span>
            <input type="Driver_no" placeholder="Type Here..." name= "Driver_no"required>
          </div>
          <div class="input-box">
            <span class="details"style="font-style: italic;">Plate Number</span>
            <input type="plate" placeholder="Type Here..." name= "Plate_number"required>
          </div>
          <div class="input-box">
            <span class="details"style="font-style: italic;">Car Model</span>
            <input type="model" placeholder="Type Here..." name= "Car_model"required>
          </div>
          <div class="input-box">
            <span class="details"style="font-style: italic;">Car Brand</span>
            <input type="brand" placeholder="Type Here..." name= "Car_brand"required>
          </div>
          <div class="input-box">
            <span class="details"style="font-style: italic;">Car Color</span>
            <input type="ccolor" placeholder="Type Here..." name= "Car_color"required>
          </div>
        
         
          <button class="button" role="button" type="submit" name="submit">Submit</button>
          <button href="index.php"class="button" role="button" type="button" onclick="myFunction()" formnovalidate>Go Back</button>
          
      
          <form action="carexcel.php" method="post">
          <button type="submit" class="button" role="button" name="export">Export</button></form>
      </div>
    </div>
  </div>

</body>
</html>
