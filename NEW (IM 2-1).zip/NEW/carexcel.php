<?php
$connect = mysqli_connect("localhost","root","","gatepass_db");
$output = '';
if (isset($_POST["export"])){
    $query = "SELECT * FROM cars";
    $result = mysqli_query($connect,$query);
    if(mysqli_num_rows($result)>0){
        $output .= '
            <table class="table" bordered="1">
                <tr>
                    <th>ID</th>
                    <th>Plate Number</th>
                    <th>Owner Name</th>
                    <th>Owner Number</th>
                    <th>Driver Name</th>
                    <th>Driver Number</th>
                    <th>Car Model</th>
                    <th>Car Brand</th>
                    <th>Car Color</th>
                </tr>
        ';
        while($row = mysqli_fetch_array($result)){
            $output .='
                <tr>
                    <td>'.$row["id"].'</td>
                    <td>'.$row["Plate_number"].'</td>
                    <td>'.$row["Owner_name"].'</td>
                    <td>'.$row["Owner_no"].'</td>
                    <td>'.$row["Driver_name"].'</td>
                    <td>'.$row["Driver_no"].'</td>
                    <td>'.$row["Car_model"].'</td>
                    <td>'.$row["Car_brand"].'</td>
                    <td>'.$row["Car_color"].'</td>
                </tr>
            ';
        }
        $output .='</table>';
        header("Content-Type: application/xls");
        header("Content-Disposition:attachment; filename=carlog.xls");
        echo $output;
    }

}