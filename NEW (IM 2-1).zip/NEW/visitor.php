<?php 

session_start();

$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "gatepass_db";
//replication to save on historical database
$dbhostH = "localhost";
$dbuserH = "root";
$dbpassH = "";
$dbnameH = "historicalgatepass_db";

    $conn= mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
    $connH= mysqli_connect($dbhostH,$dbuserH,$dbpassH,$dbnameH);

    if(isset($_POST['submit']))
    {
        $name= $_POST['name'];
        $Address= $_POST['Address'];
        $Time_in= $_POST['Time_in'];
        $purpose= $_POST['purpose'];
        $License= $_POST['License'];

        if(!empty($name) && !empty($Address) && !empty($Time_in) 
        && !empty($purpose) && !empty($License)){
            
            $query = "insert into visitors (name,Address,Time_in,purpose,License) values ('$name',
            '$Address',' $Time_in',' $purpose','$License') ";

            $run=mysqli_query($conn,$query);
            $run=mysqli_query($connH,$query);

            if($run){
               echo '<script>alert("Successfuly submitted")</script>';
               //header("Location: index.php");
            }
        }else {
            echo "error";
        }
    }


?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8" />
    <title>Visitor Registration</title>
    <link rel="stylesheet" href="visitor.css" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  </head>
  <script>
    function myFunction() {
      location.href = "index.php";
    }
  </script>
  <body>
    <style>
      body {
        background-image: url("img/Ai.jpg");
        background-color: #2e435e;
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-size: 100%;
        
      }
    </style>
    
    <div class="container">
      <div class="title"style="font-family: Garamond;">Visitor's Log Book</div>
      <div class="content">
        <form action="#" method="POST">
          <div class="user-details">
                <div class="input-box">
                  <span class="details" style="font-style: italic;">Full Name</span>
                  <input type="name" placeholder="Type here" name="name" required />
                </div>
                <div class="input-box">
                  <span class="details" style="font-style: italic;">Address/ Company Name</span>
                  <input
                    type="Address"
                    placeholder="Type here"
                    name="Address"
                    required
                  />
                </div>
                <div class="input-box">
                  <span class="details" style="font-style: italic;">Time In</span>
                  <input type="datetime-local" name="Time_in" id="tin" required />
                </div>
                <div class="input-box">
                  <span class="details" style="font-style: italic;">Purpose of Visit</span>
                  <input type="purpose"  name="purpose" placeholder="Type here" required/>
                </div>
                <div class="input-box">
                  <span class="details" style="font-style: italic;">License ID being Surendered</span>
                  <input type="License" name="License" placeholder="Type here" required/>
                </div>
            <br><br>
            <button class="button" role="button" type="submit"  name="submit">Check-In </button><br>
            <button class="button" role="button" href="index.php" type="button" onclick="myFunction()" formnovalidate>Go Back</button>
      </div> 
    </div>
  </body>
</html>

