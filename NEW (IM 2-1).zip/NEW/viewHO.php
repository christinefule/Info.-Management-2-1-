<!DOCTYPE html>
    <head>
    <link rel="stylesheet" href="viewHO.css">
        <title>View Existing Homeowners </title>
    <script>
        function myFunction() {
        location.href = "index.php";
        }
  </script>
    </head>
    <body>
    <style>
      body {
        background-image: url("img/bgvisitorrr.jpg");
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-size: 100%;
      }
    </style>
    <div class="container1">
        <center>
            <h1 style="font-family: Garamond;">Search Data from Current Database</h1>
                <form action="" method="POST">
                    <div class="user-details">
                        <div class="input-box">
                            <input type="text" name="Lastname" placeholder="Enter Lastname of the Homeowner"/>
                      </div>
                    <button class="button" role="button" type="submit" name="search">Search</button><br>
                    <button class="button" role="button" type="button" href="index.php" onclick="myFunction()" formnovalidate>
                    Go Back</button>
    </div>
    </center>
    </body>
</html>

<?php
$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection,'gatepass_db');

if(isset($_POST['search'])){
    $Lastname = $_POST['Lastname'];
    $query = "SELECT * FROM clients where Lastname='$Lastname' ";
    $query_run = mysqli_query($connection,$query);

    while($row = mysqli_fetch_array($query_run)){
        ?>  
            <form action="" method="POST">
            <table>
                <tr>
                    <th>Firstname</th>
                    <th>Lastname</th>
                    <th>Email</th>
                    <th>Street Name/ #</th>
                </tr>
                <br><br><br> <tr>
                    <td><input class="fname" type="text" name="Firstname" readonly value="<?php echo $row['Firstname'] ?>"/> </td>
                    <td><input class="lname" type="text" name="Lastname" readonly value="<?php echo $row['Lastname'] ?>"/></br></td>
                    <td><input type="text" name="Email" readonly  value="<?php echo $row['Email'] ?>"/></td>
                    <td><input type="text" name="Street_name_no" readonly value="<?php echo $row['Street_name_no'] ?>"/></br></td></tr>
                    </div>
                </tr>
                </br>
                <tr>
                <th>Password</th>
                <th>Phone number</th>
                <th>Family member</th>
                </tr>
                <tr>
                <td><input type="text" name="Phone_number" readonly value="<?php echo $row['Phone_number'] ?>"/></br></td>
                <td><input type="text" name="Family_member" readonly value="<?php echo $row['Family_member'] ?>"/></td>
                <td><input type="text" name="No_car" readonly value="<?php echo $row['No_car'] ?>"/></td>
                </tr>
                </table>
<?php
    }
}
?>       
  
