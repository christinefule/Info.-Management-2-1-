<?php
    require_once("connection.php");
    $query = "SELECT * FROM visitors";
    $result = mysqli_query($con,$query);



?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
  <title>Visitor's List</title>
    <meta charset="UTF-8" />
    <link rel="stylesheet" href="visitorview.css" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round|Open+Sans">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
  </head>
  <script>
    function myFunction() {
      location.href = "index.php";
    }
  </script>
  <br><br><br><br>
   <div class="col-sm-8" ><h1><b>Visitor's Details</b></h1></div>
  <body>
  <style>
      body {
        background-image: url("img/Ai.jpg");
        background-color: #2e435e;
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-size: 100%;
      }
    </style>
  <div class="container-lg">
    <div class="table-responsive">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    
                </div>
            </div>
            <table class="table table-bordered">
            <thead>   
                  <th change="true">FULLNAME</th>
                  <th change="true">No. of Visitors</th>
                  <th change="true">ADDRESS</th>
                  <th change="true">TIME-IN</th>
                  <th change="true">TIME-OUT</th>
                  <th change="true">PURPOSE</th>
                  <th change="true">LICENSE</th>
                  <th change="true">ACTIVITY</th>
            </thead>

            <?php
              
              while($row= mysqli_fetch_assoc($result)){
                $Name = $row['name'];
                $Id = $row['id'];
                $Address = $row['Address'];
                $TimeIn = $row['Time_in'];
                $TimeOut = $row['Time_out'];
                $Purpose = $row['purpose'];
                $License = $row['License'];
            ?>
            <tr>
                <td><?php echo $Name?></td>
                <td><?php echo $Id?></td>
                <td><?php echo $Address?></td>
                <td><?php echo $TimeIn?></td>
                <td><?php echo $TimeOut?></td>
                <td><?php echo $Purpose?></td>
                <td><?php echo $License?></td>
        
               <td>
                 <a class="edit" title="Edit" data-toggle="tooltip"><a class="material-icons"href="visitoredit.php?GetID=<?php echo $Id?>">&#xE254;</a></a>
                <a class="delete" title="Delete" data-toggle="tooltip"><a class="material-icons"href="visitordel.php?Del=<?php echo $Id?>">&#xE872;</a></a>
               </td>
          </tr>
            <?php
                }//end of while loop that displays table data
            ?>
           </table>
           <div class="container">
      <div class="content">
      <form action="#" method="POST">
          <div class="user-details">
        <button href="index.php"class="button" role="button" type="button" onclick="myFunction()" formnovalidate>Go Back</button>
        <br><form action="visitorexcel.php" method="post">
          <button type="submit" class="button" role="button" name="export">Export</button></form>
          </form> </div></div>
    </div>
  </div>
</body>
</html>