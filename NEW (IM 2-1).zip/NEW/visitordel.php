<?php 
    require_once("connection.php");
    
    if(isset($_GET['Del'])){
        $Id = $_GET['Del'];
        $query = "delete from visitors where id ='".$Id."'";
        $result = mysqli_query($con,$query);

        if($result){
            header("location:visitorview.php");
        }
        else{
            echo ' Please check your query';
        }
    }

?>