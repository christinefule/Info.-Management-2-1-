<!DOCTYPE html>
<html lang="en">
<head>
  <title>MAIN MENU</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="index.css">
</head>
<body>
<div class="our-services">
<img src="img/bgbg.png" alt="logo">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <div class="service-box">
          <div class="row">
            <div class="col-3">
              <i class="fa fa-address-book" style="font-size:70px" aria-hidden="true"></i>
            </div>
            <div class="col-9">
              <h3><a href="viewHO.php">View Current Homeowners</a></h3>
              <h5><b>Click to View:</b><br></h5> <p style="font-style: italic;">Information of the Homeowners. Check if the information stated by the Visitor is true. </p>
            </div>
          </div>
        </div>
      </div>
      
      <div class="col-md-6">
        <div class="service-box">
          <div class="row">
            <div class="col-3">
              <i class="fa fa-street-view" style="font-size:70px" aria-hidden="true"></i>

            </div>
            <div class="col-9">
              <h3><a href="visitorview.php">Edit Visitor's Log</a></h3>
              <h5><b>Click to View:</b><br></h5> <p style="font-style: italic;">Visitor's Log that is currently recorded. Edit/Delete if the visitors's current data is correct/wrong.</p>
            </div>
          </div>
        </div>
      </div>

      <div class="col-md-6">
        <div class="service-box">
          <div class="row">
            <div class="col-3">
              <i class="fa fa-pencil-square-o" style="font-size:70px" aria-hidden="true"></i>
            </div>
            <div class="col-9">
              <h3><a href="visitor.php">Visitor's Log</a></h3>
              <h5><b>Click to View:</b><br></h5> <p style="font-style: italic;">Visitor's Information. This includes Name, Address,Time in/out, Purpose of Visit and ID provided.</p>
            </div>
          </div>
        </div>
      </div>

      <div class="col-md-6">
        <div class="service-box">
          <div class="row">
            <div class="col-3">
              <i class="fa fa-car" style="font-size:70px"  aria-hidden="true"></i>
            </div>
            <div class="col-9">
              <h3><a href="car.php">Car Registration</a></h3>
              <h5><b>Click to View:</b><br></h5> <p style="font-style: italic;">Car Information. This includes Plate Number, Owner Name,Car model, Car brand and Car color.</p>
            </div>
          </div>
        </div>
      </div>

      <div class="col-md-6">
        <div class="service-box">
          <div class="row">
            <div class="col-3">
              
              <i class="fa fa-user-plus" style="font-size:70px"  aria-hidden="true"></i>
            </div>
            <div class="col-9">
              <h3><a href="newhomeowner.php">Add new Homeowner</a></h3>
              <h5><b>Click to View:</b><br></h5> <p style="font-style: italic;">Homeowner's Information. This includes Firstname, Lastname, Address, Contact Number.</p>
            </div>
          </div>
        </div>
      </div>

      <div class="col-md-6">
        <div class="service-box">
          <div class="row">
            <div class="col-3">
              <i class="fa fa-sign-out" style="font-size:70px"  aria-hidden="true"></i>
            </div>
            <div class="col-9">
              <h3><a href="logout.php">Logout</a></h3>
              <h5><b>Click to View:</b><br></h5> <p style="font-style: italic;">After clicking this the page will go back to Log In screen which will ask the guard on shift to Login </p>
              <p></p>
</div></div></div></div>
<footer>
        <div class="footer-content">
            <h3>Aspire by Filinvest</h3>
            <p><b>Discover, Elegance, and Serenity</b></p>
            <p>Experience the good life that you deserve at Ashton Fields, a charming residential community in Calamba, Laguna. Enjoy peace of mind as you reside in this safe and secure neighborhood.</p>
            <ul class="socials">
                <li><a href="https://www.facebook.com/Ashtonbyfilinvest/"><i class="fa fa-facebook"></i></a></li>
                <li><a href="https://www.filinvestlegacy.com/filinvest-ashton-fields-calamba-laguna-house-lot/"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="https://www.filinvestlegacy.com/filinvest-ashton-fields-calamba-laguna-house-lot/"><i class="fa fa-linkedin-square"></i></a></li>
            </ul>
        </div>
        <div class="footer-bottom">
            <p>copyright &copy; <a href="https://www.filinvestlegacy.com/filinvest-ashton-fields-calamba-laguna-house-lot/">Junior Developer</a></p>
                    <div class="footer-menu">
                      <ul class="f-menu">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="https://www.filinvestlegacy.com/filinvest-ashton-fields-calamba-laguna-house-lot/">About</a></li>
                        <li><a href="https://www.filinvestlegacy.com/filinvest-ashton-fields-calamba-laguna-house-lot/">Blog</a></li>
                      </ul>
                    </div>
        </div>
    </footer>
</body>
</html>
