<?php
$connect = mysqli_connect("localhost","root","","gatepass_db");
$output = '';
if (isset($_POST["export"])){
    $query = "SELECT * FROM visitors";
    $result = mysqli_query($connect,$query);
    if(mysqli_num_rows($result)>0){
        $output .= '
            <table class="table" bordered="1">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Time in</th>
                    <th>Time out</th>
                    <th>Purpose</th>
                    <th>License</th>
                </tr>
        ';
        while($row = mysqli_fetch_array($result)){
            $output .='
                <tr>
                    <td>'.$row["id"].'</td>
                    <td>'.$row["name"].'</td>
                    <td>'.$row["Address"].'</td>
                    <td>'.$row["Time_in"].'</td>
                    <td>'.$row["Time_out"].'</td>
                    <td>'.$row["purpose"].'</td>
                    <td>'.$row["License"].'</td>
                </tr>
            ';
        }
        $output .='</table>';
        header("Content-Type: application/xls");
        header("Content-Disposition:attachment; filename=visitorlog.xls");
        echo $output;
    }

}