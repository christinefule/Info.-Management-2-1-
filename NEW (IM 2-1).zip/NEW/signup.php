<?php 
session_start();

	include("connection.php");
	include("functions.php");

//replication to save on historical database
$dbhostH = "localhost";
$dbuserH = "root";
$dbpassH = "";
$dbnameH = "historicalgatepass_db";

$connH= mysqli_connect($dbhostH,$dbuserH,$dbpassH,$dbnameH);

	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//something was posted
		$user_name = $_POST['user_name'];
		$password = $_POST['password'];

		if(!empty($user_name) && !empty($password) && !is_numeric($user_name))
		{

			//save to database
			$user_id = random_num(20);
			$query = "insert into users (user_id,user_name,password) values ('$user_id','$user_name','$password')";

			mysqli_query($con, $query);mysqli_query($connH, $query);

			header("Location: login.php");
			die;
		}else
		{
			echo "Please enter some valid information!";
		}
	}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8" />
    <title>Guard Sign Up</title>
    <link rel="stylesheet" href="signup.css" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  </head>
  <script>
    function myFunction() {
      location.href = "login.php";
    }
  </script>
  <body>
    <style>
      body {
        background-image: url("img/bgsignup.png");
      }
    </style>
    <div class="container">
      <div class="title">Guard Sign up</div>
      <div class="content">
        <form action="#" method="post">
          <div class="user-details">
            <div class="input-box">
              <span class="details">Fullname</span>
              <input
                type="text"
                name="name"
                placeholder="Enter your name"
                required
              />
            </div>

            <div class="input-box">
              <span class="details">Username</span>
              <input
                type="text"
                name="user_name"
                placeholder="Enter your username"
                required
              />
            </div>

            <div class="input-box">
              <span class="details">Password</span>
              <input type="password" name="password" placeholder="Enter your password" required />
            </div>

            <div class="input-box">
              <span class="details">Re-type Password</span>
              <input type="password" placeholder="Confirm password" required />
            </div>
          </div>

          <div class="button">
            <input type="submit" value="Register" />
          </div>
          <div class="button">
            <input
              type="button"
              value="Already have an Account"
              onclick="myFunction()"
              formnovalidate
            />
          </div>
        </form>
      </div>
    </div>
  </body>
</html>

