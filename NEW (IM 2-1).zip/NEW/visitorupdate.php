<?php
session_start();

$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "gatepass_db";
//replication to save on historical database
$dbhostH = "localhost";
$dbuserH = "root";
$dbpassH = "";
$dbnameH = "historicalgatepass_db";
    
    $conn= mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
    $connH= mysqli_connect($dbhostH,$dbuserH,$dbpassH,$dbnameH);

    if(isset($_POST['update'])){
        $id = $_GET['id'];
        $name= $_POST['fname'];
        $Address= $_POST['Address'];
        $Time_out= $_POST['Time_out'];
        $purpose= $_POST['purpose'];
        $License= $_POST['License'];

        $query = "UPDATE visitors SET name='$name',Address = '$Address',Time_out = '$Time_out',purpose= '$purpose',License = '$License' WHERE id=$id";
        $result= mysqli_query($conn,$query);
        $result= mysqli_query($connH,$query);
        
        if($result)
        {
            header("location:visitorview.php");
        }
        else{
            echo 'Please Check Your Query ';
        }
    }
    else{
        header("location:visitorview.php");
    }
?>