<?php 
session_start();

$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "gatepass_db";


    $conn= mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);

    $Id=$_GET['GetID'];
    $query = "SELECT * FROM visitors WHERE id='".$Id."'";
    $result = mysqli_query($conn,$query);

    while($row=mysqli_fetch_assoc($result)){
            $Id = $row['id'];
            $Name = $row['name'];
            $Address = $row['Address'];
            $TimeOut = $row['Time_out'];
            $Purpose = $row['purpose'];
            $License = $row['License'];
    }

?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8" />
    <title>UPDATE VISITOR</title>
    <link rel="stylesheet" href="visitor.css" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  </head>
  <script>
    function myFunction() {
      location.href = "visitorview.php";
    }
  </script>
  <body>
    <style>
      body {
        background-image: url("img/Ai.jpg");
        background-color: #2e435e;
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-size: 100%;
      }
    </style>
    <div class="container">
      <div class="title">Update Visitor's Log </div>
      <div class="content">
        <form action="visitorupdate.php?id=<?php echo $Id?>" method="POST">
          <div class="user-details">
            <div class="input-box">
              <span class="details">Full Name</span>
              <input type="name" placeholder="Type here" name="fname" value="<?php echo $Name ?>" required />
            </div>
            <div class="input-box">
              <span class="details">Address/ Company Name</span>
              <input
                type="Address"
                placeholder="Type here"
                name="Address"
                value="<?php echo $Address?>"
                required
              />
            </div>
            <div class="input-box">
              <span class="details">Time out</span>
              <input type="datetime-local" name="Time_out" id="tot"value=""/>
            </div>
            <div class="input-box">
              <span class="details">Purpose of Visit</span>
              <input
                type="purpose"
                name="purpose"
                placeholder="Type here"
                value="<?php echo $Purpose?>"
                required
              />
            </div>
            <div class="input-box">
              <span class="details">License being Surendered</span>
              <input type="License" name="License"placeholder="Type here" value="<?php echo $License?>" required/>
            </div><br>

          <button class="button" role="button" type="submit" name="update">Update</button>
          <button class="button" role="button" type="button" onclick="myFunction()" formnovalidate>Go Back</button>
          </div>
        </form>
      </div>
    </div>
  </body>
</html>

