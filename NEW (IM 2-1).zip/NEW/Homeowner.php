<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset = "UTF-8">
        <meta name="viewport" content = "width=device-width, initial-scale=1.0">
        <title>GPMS</title>
    </head>

    <h1> Homeowner</h1>
    <body bgcolor = "#036e9c">
        <div><h2>Booking Details</h2></div>
        <form action = 'main.php' method ="POST">
        <div class="box">
                <label for="user"> Firstname: <label><br>
                <input type ='text' name='fname' id= "fname" required/><br>
                 
                <label for="email"> Lastname: <label><br>
                <input type ='email' name='lname' id= "lname" required/><br>

                <label for="user"> Address: <label><br>
                <input type ='text' name='add' id= "add" required/><br>
                 
                <label for="email"> Contact number: <label><br>
                <input type ='email' name='cnum' id= "cnum" required/><br>
        </form>
    <a href="index.php">Go back</a>
    </body>
</html>